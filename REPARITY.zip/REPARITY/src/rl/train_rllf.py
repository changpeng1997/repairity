#!/usr/bin/env python3
# train_rllf.py - Reinforcement Learning from LLM Feedback using PPO

import os
import json
import torch
import random
import argparse
import logging
import numpy as np
from tqdm import tqdm
from typing import List, Dict, Any
from pathlib import Path
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoModelForSequenceClassification,
    BitsAndBytesConfig,
    GenerationConfig
)
from peft import (
    PeftModel,
    PeftConfig,
    get_peft_model,
    LoraConfig,
    TaskType,
    prepare_model_for_kbit_training,
)
from trl import PPOTrainer, PPOConfig, AutoModelForCausalLMWithValueHead

# Set up logging
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%m/%d/%Y %H:%M:%S",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Train a model with RLLF using PPO")
    parser.add_argument(
        "--qwen_model", 
        type=str, 
        default="models/qwen_repairity_20250330_011532_alternating_alternating",
        help="Path to fine-tuned Qwen model"
    )
    parser.add_argument(
        "--reward_model", 
        type=str, 
        default="./models/binary_reward_model",
        help="Path to binary reward model"
    )
    parser.add_argument(
        "--dataset_path", 
        type=str, 
        default="./data/bigcode-evaluation-data.jsonl",
        help="Path to dataset for training"
    )
    parser.add_argument(
        "--output_dir", 
        type=str, 
        default="./models/qwen_rllf",
        help="Output directory for RLLF fine-tuned model"
    )
    parser.add_argument(
        "--batch_size", 
        type=int, 
        default=4,
        help="Batch size for training"
    )
    parser.add_argument(
        "--mini_batch_size", 
        type=int, 
        default=1,
        help="Mini batch size for PPO updates"
    )
    parser.add_argument(
        "--max_length", 
        type=int, 
        default=1024,
        help="Maximum sequence length"
    )
    parser.add_argument(
        "--max_prompt_length", 
        type=int, 
        default=512,
        help="Maximum prompt length"
    )
    parser.add_argument(
        "--epochs", 
        type=int, 
        default=3,
        help="Number of training epochs (PPO epochs)"
    )
    parser.add_argument(
        "--learning_rate", 
        type=float, 
        default=1e-5,
        help="Learning rate"
    )
    parser.add_argument(
        "--load_in_8bit", 
        action="store_true",
        help="Load policy model in 8-bit mode"
    )
    parser.add_argument(
        "--load_in_4bit", 
        action="store_true",
        help="Load policy model in 4-bit mode"
    )
    parser.add_argument(
        "--num_samples", 
        type=int, 
        default=100,
        help="Number of samples to use from dataset"
    )
    parser.add_argument(
        "--ppo_steps", 
        type=int, 
        default=10,
        help="Number of PPO update steps"
    )
    parser.add_argument(
        "--max_new_tokens", 
        type=int, 
        default=512,
        help="Maximum number of new tokens to generate"
    )
    return parser.parse_args()

def prepare_dataset(dataset_path: str, num_samples: int = None):
    """Load and prepare the dataset for training."""
    logger.info(f"Loading dataset from {dataset_path}")
    
    if dataset_path.endswith('.jsonl'):
        # Load from JSONL file
        with open(dataset_path, 'r') as f:
            data = [json.loads(line) for line in f]
    else:
        # Load from JSON file
        with open(dataset_path, 'r') as f:
            data = json.load(f)
    
    logger.info(f"Loaded {len(data)} examples from dataset")
    
    # Format dataset
    formatted_data = []
    for item in data:
        # Assuming each item has 'input' field
        formatted_data.append({
            "query": item.get("input", ""),
            "input": item.get("input", "")
        })
    
    # Sample if requested
    if num_samples and num_samples < len(formatted_data):
        logger.info(f"Sampling {num_samples} examples from dataset")
        formatted_data = random.sample(formatted_data, num_samples)
    
    return formatted_data

def load_reward_model(reward_model_path: str):
    """Load the binary reward model."""
    logger.info(f"Loading reward model from {reward_model_path}")
    
    # Try to load as a PEFT model first
    try:
        config = PeftConfig.from_pretrained(reward_model_path)
        logger.info(f"Loading base model: {config.base_model_name_or_path}")
        
        reward_model = AutoModelForSequenceClassification.from_pretrained(
            config.base_model_name_or_path,
            num_labels=2,
            device_map="auto"
        )
        reward_model = PeftModel.from_pretrained(reward_model, reward_model_path)
        logger.info(f"Loaded PEFT reward model based on {config.base_model_name_or_path}")
    except Exception as e:
        logger.info(f"Loading as standard model: {str(e)}")
        # Fall back to regular model loading
        reward_model = AutoModelForSequenceClassification.from_pretrained(
            reward_model_path,
            device_map="auto"
        )
    
    tokenizer = AutoTokenizer.from_pretrained(reward_model_path)
    if tokenizer.pad_token is None:
        if tokenizer.eos_token is not None:
            tokenizer.pad_token = tokenizer.eos_token
        else:
            tokenizer.pad_token = tokenizer.eos_token = "</s>"
    
    return reward_model, tokenizer

def get_reward(
    reward_model,
    reward_tokenizer,
    batch_inputs,
    batch_outputs,
    max_length=1024
):
    """Get rewards from the reward model."""
    rewards = []
    
    # Get device - safely handle models that might not have .device attribute
    device = next(reward_model.parameters()).device
    
    for input_text, output_text in zip(batch_inputs, batch_outputs):
        # Format as expected by reward model
        combined_text = f"Task: {input_text}\n\nSolution: {output_text}"
        
        # Tokenize
        inputs = reward_tokenizer(
            combined_text,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length
        )
        
        # Move to device
        for key in inputs:
            inputs[key] = inputs[key].to(device)
        
        # Get model prediction
        with torch.no_grad():
            outputs = reward_model(**inputs)
            logits = outputs.logits
            probabilities = torch.softmax(logits, dim=1)
            
            # Get "GOOD" class probability as reward
            reward = probabilities[0][1].item()  # Probability of class 1 (GOOD)
            rewards.append(reward)
    
    return torch.tensor(rewards, dtype=torch.float)

def format_for_ppo(tokenizer, dataset):
    """Format dataset for PPO training."""
    formatted = []
    for item in dataset:
        query = item["query"]
        # Tokenize inputs for PPO format
        tokenized_query = tokenizer(
            query,
            return_tensors="pt",
            padding=True,
            truncation=True,
        )
        
        formatted.append({
            "input_ids": tokenized_query.input_ids[0],
            "attention_mask": tokenized_query.attention_mask[0],
            "query": query,
        })
    return formatted

def custom_training_loop(
    policy_model,
    policy_tokenizer,
    reward_model,
    reward_tokenizer,
    dataset,
    args
):
    """Implement custom PPO training loop without using PPOTrainer."""
    logger.info("Starting custom PPO training loop")
    
    # Get device - safely handle models that might not have .device attribute
    device = next(policy_model.parameters()).device
    logger.info(f"Using device: {device}")
    
    # Enable gradient checkpointing
    if hasattr(policy_model, 'gradient_checkpointing_enable'):
        policy_model.gradient_checkpointing_enable()
        logger.info("Enabled gradient checkpointing")
    
    # Optimizer
    optimizer = torch.optim.Adam(
        filter(lambda p: p.requires_grad, policy_model.parameters()),
        lr=args.learning_rate
    )
    
    # Training loop
    for epoch in range(args.ppo_steps):
        logger.info(f"Starting epoch {epoch+1}/{args.ppo_steps}")
        
        # Process in batches
        for batch_idx in range(0, len(dataset), args.batch_size):
            batch_end = min(batch_idx + args.batch_size, len(dataset))
            batch = dataset[batch_idx:batch_end]
            
            # Clear CUDA cache
            torch.cuda.empty_cache()
            
            # Extract queries
            batch_queries = [item["query"] for item in batch]
            
            # Tokenize queries with reduced max length
            batch_inputs = policy_tokenizer(
                batch_queries,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=min(args.max_prompt_length, 256)  # Reduce max length
            )
            
            # Move to device
            for key in batch_inputs:
                batch_inputs[key] = batch_inputs[key].to(device)
            
            # Generate responses with current policy
            batch_responses = []
            with torch.no_grad():
                for i in range(len(batch_queries)):
                    input_ids = batch_inputs.input_ids[i].unsqueeze(0)
                    attention_mask = batch_inputs.attention_mask[i].unsqueeze(0)
                    
                    # Generate response with reduced max tokens
                    try:
                        outputs = policy_model.generate(
                            input_ids=input_ids,
                            attention_mask=attention_mask,
                            max_new_tokens=min(args.max_new_tokens, 256),  # Reduce max tokens
                            temperature=0.7,
                            top_p=0.9,
                            do_sample=True,
                            pad_token_id=policy_tokenizer.pad_token_id,
                            eos_token_id=policy_tokenizer.eos_token_id,
                        )
                    except Exception as e:
                        logger.error(f"Error in generation: {e}")
                        continue
                    
                    # Extract only the generated part (without prompt)
                    response_text = policy_tokenizer.decode(
                        outputs[0][len(input_ids[0]):], 
                        skip_special_tokens=True
                    )
                    batch_responses.append(response_text)
            
            if not batch_responses:  # Skip if no responses were generated
                continue
            
            # Get rewards from the reward model
            rewards = get_reward(
                reward_model,
                reward_tokenizer,
                batch_queries,
                batch_responses,
                max_length=min(args.max_length, 512)  # Reduce max length
            )
            
            # Log rewards
            logger.info(f"Epoch {epoch+1}, Batch {batch_idx//args.batch_size + 1} rewards: {rewards.tolist()}")
            
            # Prepare for policy update
            for i in range(len(batch_queries)):
                try:
                    # Tokenize full sequence (prompt + response)
                    full_text = batch_queries[i] + batch_responses[i]
                    inputs = policy_tokenizer(
                        full_text,
                        return_tensors="pt",
                        truncation=True,
                        max_length=min(args.max_length, 512)  # Reduce max length
                    )
                    
                    # Move to device
                    for key in inputs:
                        inputs[key] = inputs[key].to(device)
                    
                    # Forward pass to get logits
                    try:
                        outputs = policy_model(
                            input_ids=inputs.input_ids,
                            attention_mask=inputs.attention_mask,
                            return_dict=True
                        )
                    except Exception as e:
                        logger.warning(f"Error in forward pass: {e}")
                        continue
                    
                    # Calculate simple policy gradient loss
                    logits = outputs.logits
                    log_probs = torch.nn.functional.log_softmax(logits, dim=-1)
                    
                    # Extract log probabilities of the tokens that were actually generated
                    token_log_probs = torch.gather(
                        log_probs[0, :-1], 
                        dim=1, 
                        index=inputs.input_ids[0, 1:].unsqueeze(1)
                    ).squeeze(1)
                    
                    # Calculate loss (negative of reward * log_prob)
                    # Only consider generated part
                    prompt_length = len(policy_tokenizer.encode(batch_queries[i])) - 2  # Account for special tokens
                    response_log_probs = token_log_probs[prompt_length:]
                    
                    # Policy gradient loss
                    loss = -rewards[i] * response_log_probs.sum()
                    
                    # Backward pass and optimize
                    loss.backward()
                    
                except Exception as e:
                    logger.error(f"Error in processing example {i}: {e}")
                    continue
            
            # Update model
            optimizer.step()
            optimizer.zero_grad()
            
            # Clear CUDA cache after each batch
            torch.cuda.empty_cache()
        
        # After each epoch, save a checkpoint
        checkpoint_dir = os.path.join(args.output_dir, f"checkpoint-{epoch+1}")
        os.makedirs(checkpoint_dir, exist_ok=True)
        
        # Save policy model with error handling
        try:
            policy_model.save_pretrained(checkpoint_dir)
            policy_tokenizer.save_pretrained(checkpoint_dir)
            logger.info(f"Saved checkpoint to {checkpoint_dir}")
        except Exception as e:
            logger.error(f"Error saving checkpoint: {e}")
    
    return policy_model

def main():
    args = parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Set up file logger
    file_handler = logging.FileHandler(os.path.join(args.output_dir, "rllf_training.log"))
    logger.addHandler(file_handler)
    
    # Log all arguments
    logger.info(f"Training with arguments: {args}")
    
    # Prepare dataset
    dataset = prepare_dataset(args.dataset_path, args.num_samples)
    
    # Set up quantization config if needed
    quantization_config = None
    if args.load_in_4bit:
        logger.info("Using 4-bit quantization for policy model")
        quantization_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True
        )
    elif args.load_in_8bit:
        logger.info("Using 8-bit quantization for policy model")
        quantization_config = BitsAndBytesConfig(
            load_in_8bit=True
        )
    
    # Load policy model (Qwen)
    logger.info(f"Loading Qwen policy model from {args.qwen_model}")
    policy_model = AutoModelForCausalLM.from_pretrained(
        args.qwen_model,
        quantization_config=quantization_config,
        device_map="auto",
        torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        trust_remote_code=True
    )
    policy_tokenizer = AutoTokenizer.from_pretrained(
        args.qwen_model,
        trust_remote_code=True
    )
    
    if policy_tokenizer.pad_token is None:
        if policy_tokenizer.eos_token is not None:
            policy_tokenizer.pad_token = policy_tokenizer.eos_token
        else:
            policy_tokenizer.pad_token = policy_tokenizer.eos_token = "</s>"
    
    # Load reward model
    reward_model, reward_tokenizer = load_reward_model(args.reward_model)
    
    # Skip the PPOTrainer approach and go directly to custom training
    logger.info("Using direct model training with custom loop")
    
    # If using quantization, apply LoRA to base model
    if args.load_in_4bit or args.load_in_8bit:
        logger.info("Setting up LoRA for base policy model")
        policy_model = prepare_model_for_kbit_training(policy_model)
        
        # Configure LoRA
        peft_config = LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            inference_mode=False,
            r=16,
            lora_alpha=32,
            lora_dropout=0.05,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]
        )
        
        policy_model = get_peft_model(policy_model, peft_config)
        policy_model.print_trainable_parameters()
    
    # Run custom training loop
    policy_model = custom_training_loop(
        policy_model,
        policy_tokenizer,
        reward_model,
        reward_tokenizer,
        dataset,
        args
    )
    
    # Save final model - with error handling
    try:
        final_model_dir = os.path.join(args.output_dir, "final-model")
        os.makedirs(final_model_dir, exist_ok=True)
        policy_model.save_pretrained(final_model_dir)
        policy_tokenizer.save_pretrained(final_model_dir)
        logger.info(f"Saved final model to {final_model_dir}")
    except Exception as e:
        logger.error(f"Error saving final model: {e}")
        
        # Try different saving methods
        try:
            logger.info("Attempting alternative saving method...")
            if hasattr(policy_model, 'save_pretrained'):
                policy_model.save_pretrained(final_model_dir)
            elif hasattr(policy_model, 'model') and hasattr(policy_model.model, 'save_pretrained'):
                policy_model.model.save_pretrained(final_model_dir)
            elif hasattr(policy_model, 'base_model') and hasattr(policy_model.base_model, 'save_pretrained'):
                policy_model.base_model.save_pretrained(final_model_dir)
            else:
                logger.error("Couldn't find appropriate method to save model")
                
            # Always save tokenizer
            policy_tokenizer.save_pretrained(final_model_dir)
            logger.info(f"Saved model using alternative method to {final_model_dir}")
        except Exception as e2:
            logger.error(f"Alternative saving method also failed: {e2}")
    
    # Try to save unwrapped model if available - with error handling
    try:
        unwrapped_model = None
        unwrapped_dir = os.path.join(args.output_dir, "unwrapped-model")
        os.makedirs(unwrapped_dir, exist_ok=True)
        
        # Try different attributes to find base model
        if hasattr(policy_model, 'pretrained_model'):
            unwrapped_model = policy_model.pretrained_model
        elif hasattr(policy_model, 'base_model'):
            unwrapped_model = policy_model.base_model
        elif hasattr(policy_model, 'model'):
            unwrapped_model = policy_model.model
            
        if unwrapped_model is not None:
            unwrapped_model.save_pretrained(unwrapped_dir)
            policy_tokenizer.save_pretrained(unwrapped_dir)
            logger.info(f"Saved unwrapped model to {unwrapped_dir}")
        else:
            logger.info("No base model attribute found, skipping unwrapped model save")
            
    except Exception as e:
        logger.warning(f"Error saving unwrapped model: {e}")
        logger.info("Skipping unwrapped model save")
    
    logger.info("RLLF training complete!")

if __name__ == "__main__":
    main()