#!/bin/bash

# Optimized training script for Qwen 7B model on RTX 5000 Ada

# Make script executable with: chmod +x train_qwen_optimized.sh

# First, set environment variables for better GPU memory management
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True,max_split_size_mb:128
export CUDA_VISIBLE_DEVICES=0

# Clear GPU cache
echo "Clearing GPU cache..."
python -c "import torch; torch.cuda.empty_cache(); print('GPU cache cleared')"

# Activate the environment
echo "Activating REPAIRITY environment..."
source $(conda info --base)/etc/profile.d/conda.sh
conda activate REPAIRITY

# Install any missing dependencies
echo "Checking for missing dependencies..."
pip install -q transformers>=4.35.0 bitsandbytes>=0.41.0 peft>=0.6.0 accelerate>=0.26.0

# Run the training with optimized parameters
echo "Starting Qwen 7B training with optimized parameters..."
python -m src.main sft \
    --model qwen-7b \
    --claude_data_path ./data/claude_reasoning_traces_v0.1.4_100.json \
    --reasoning_strategy explicit \
    --batch_size 1 \
    --num_epochs 1 \
    --output_dir ./models/qwen_rtx5000_optimized

echo "Training complete!" 