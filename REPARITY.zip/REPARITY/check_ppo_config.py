#!/usr/bin/env python3
# check_ppo_config.py

from trl import PPOConfig
import inspect

def main():
    # Get the signature of PPOConfig.__init__ 
    sig = inspect.signature(PPOConfig.__init__)
    
    # Print the parameters
    print("PPOConfig parameters:")
    for param_name, param in sig.parameters.items():
        if param_name != 'self':
            print(f"  {param_name}: {param.default}")
    
    # Create a simple PPOConfig
    config = PPOConfig()
    print("\nDefault PPOConfig attributes:")
    for attr in dir(config):
        if not attr.startswith('_'):
            value = getattr(config, attr)
            if not callable(value):
                print(f"  {attr}: {value}")

if __name__ == "__main__":
    main() 