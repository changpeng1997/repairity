#!/usr/bin/env python3
import json
import os

def main():
    """Convert Claude examples to JSONL format for RLLF training."""
    # Load Claude examples
    input_file = "data/claude_reasoning_traces_v0.1.4_100.json"
    output_file = "data/bigcode-evaluation-data.jsonl"
    
    print(f"Converting examples from {input_file} to {output_file}")
    
    with open(input_file, 'r') as f:
        examples = json.load(f)
    
    print(f"Loaded {len(examples)} examples")
    
    # Convert to JSONL format
    with open(output_file, 'w') as f:
        for example in examples:
            # Format each example as needed for RLLF training
            jsonl_entry = {
                "input": example["task"],
                "id": example["task_id"]
            }
            f.write(json.dumps(jsonl_entry) + "\n")
    
    print(f"Converted {len(examples)} examples to JSONL format")
    print(f"Output written to {output_file}")

if __name__ == "__main__":
    main() 