#!/bin/bash

# Setup script for TrustCode project

echo "Setting up environment for TrustCode project..."

# Check if conda is available
if ! command -v conda &> /dev/null; then
    echo "Conda not found. Please install Miniconda or Anaconda first."
    exit 1
fi

# Create or update the REPAIRITY environment
if conda env list | grep -q "REPAIRITY"; then
    echo "Updating existing REPAIRITY environment..."
    conda activate REPAIRITY
else
    echo "Creating new REPAIRITY environment..."
    conda create -n REPAIRITY python=3.10 -y
    conda activate REPAIRITY
fi

# Install PyTorch with CUDA
echo "Installing PyTorch with CUDA support..."
conda install -y pytorch torchvision torchaudio pytorch-cuda=12.1 -c pytorch -c nvidia

# Install bitsandbytes with CUDA support
echo "Installing bitsandbytes for quantization..."
pip install -U bitsandbytes

# Install other requirements from requirements.txt
echo "Installing other dependencies from requirements.txt..."
pip install -r requirements.txt

# Environment info
echo "Environment setup complete. Displaying GPU information:"
python -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}'); print(f'CUDA version: {torch.version.cuda}'); print(f'GPU count: {torch.cuda.device_count()}'); print(f'GPU name: {torch.cuda.get_device_name(0)}' if torch.cuda.is_available() else 'No GPU available')"

echo "Setup complete! Activate the environment with: conda activate REPAIRITY" 